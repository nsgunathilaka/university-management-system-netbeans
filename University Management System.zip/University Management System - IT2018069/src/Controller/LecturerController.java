/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;
/**
 *
 * @author Hacker
 */
public class LecturerController {
    
        public static void Add_Lecturer (String name, String address, String phone, String email, String age, String gender, String faculty){
        
        new Model.AddLecturerData().Add_Lecturer(name,address, phone, email, age, gender, faculty);
        
        JOptionPane.showMessageDialog(null, "New Lecturer has been inserted","Successfull",JOptionPane.INFORMATION_MESSAGE);
    }
}
