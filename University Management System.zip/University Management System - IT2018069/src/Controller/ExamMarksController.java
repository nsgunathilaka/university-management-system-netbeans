/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Elitebook -PC
 */
public class ExamMarksController {
    
        public static void ExamMarks (String stuid, String name, String semester, String module, double caMarks, double feMarks, double totalMarks, String grade){
        
        new Model.ExamMarksData().ExamMarks(stuid, name, semester, module, caMarks, feMarks, totalMarks, grade);
        
        JOptionPane.showMessageDialog(null, "New record has been inserted","Successfull",JOptionPane.INFORMATION_MESSAGE);
    }


    
}
