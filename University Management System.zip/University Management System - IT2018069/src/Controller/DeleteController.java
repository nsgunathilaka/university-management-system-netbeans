   /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Elitebook -PC
 */

// controller package

public class DeleteController {
    
        public static void deleteStudent(String name){
        new Model.DBDelete().deleteStudent(name);
        JOptionPane.showMessageDialog(null, "The Record has been deleted.");
        
    }
        
        
  
        

        public static void deletelecturer(String name){
        new Model.DBDelete().deleteLecturer(name);
        JOptionPane.showMessageDialog(null, "The Record has been deleted.");
        
    }    
          public static void deletePayment(String name){
        new Model.DBDelete().deletePayment(name);
        JOptionPane.showMessageDialog(null, "The Record has been deleted.");
        
    }  
       
         public static void deleteMarks(String stuid){
        new Model.DBDelete().deleteMarks(stuid);
        JOptionPane.showMessageDialog(null, "The Record has been deleted.");
        
    }        

}
