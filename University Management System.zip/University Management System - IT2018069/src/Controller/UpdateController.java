/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Elitebook -PC
 */
public class UpdateController {

 public static void updateStudent(String stuid, String name, String address, String phone, String email,String course)
    { 
        
    new Model.update().updateStudent(stuid, name, address, phone, email, course);
    JOptionPane.showMessageDialog(null, "Record has been updated", "Successfull", JOptionPane.INFORMATION_MESSAGE);
  
    } 

  public static void updateLecturer(String name, String address, String phone, String email, String faculty)
    { 
        
    new Model.update().updateLecturer(name, address, phone, email, faculty);
    JOptionPane.showMessageDialog(null, "Record has been updated", "Successfull", JOptionPane.INFORMATION_MESSAGE);
  
    } 

    public static void updateResults(String stuid, String name, String semester, String module, double caMarks, double feMarks, double totalMarks, String grade)
    { 
        
    new Model.update().updateResults(stuid, name, semester, module, caMarks, feMarks, totalMarks, grade);
    JOptionPane.showMessageDialog(null, "Results has been updated", "Successfull", JOptionPane.INFORMATION_MESSAGE);
  
    } 
 
        public static void updatePayment(String stuid, String name, String semester, String amount)
    { 
        
    new Model.update().updatePayment(stuid, name, semester, amount);
    JOptionPane.showMessageDialog(null, "Record has been updated", "Successfull", JOptionPane.INFORMATION_MESSAGE);
  
    } 
}
