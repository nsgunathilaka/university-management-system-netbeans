/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;
/**
 *
 * @author Elitebook -PC
 */
public class PaymentController {
    
       public static void Payment (String stuid, String name, String semester, String amount,String paymentmethod){
        
        new Model.PaymentData().Payment(stuid, name, semester, amount,paymentmethod);
        
        JOptionPane.showMessageDialog(null, "Payment Complete","Successfull",JOptionPane.INFORMATION_MESSAGE);
    }
}
