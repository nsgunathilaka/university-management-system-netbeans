/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Hacker
 */
public class StudentsController {
    
    public static void AddStudents (String stuid, String name, String address, String phone, String email, String course, String gender){
        
        new Model.AddStudentData().AddStudents(stuid, name, address, phone, email, course, gender);
        
        JOptionPane.showMessageDialog(null, "New Student has been inserted","Successfull",JOptionPane.INFORMATION_MESSAGE);
    }
    
}
