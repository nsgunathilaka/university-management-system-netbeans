/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;
/**
 *
 * @author Elitebook -PC
 */
public class PaymentData {
    
        Statement stmt;
    
        public void Payment (String stuid, String name, String semester, String amount, String paymentmethod){
        try{
            
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate
        ("INSERT INTO payment VALUES ('"+stuid+"','"+name+"','"+semester+"','"+amount+"','"+paymentmethod+"')");
    }
        catch (Exception e){
            e.printStackTrace();
        }
}
}
