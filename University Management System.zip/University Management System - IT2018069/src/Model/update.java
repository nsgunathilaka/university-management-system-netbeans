/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Elitebook -PC
 */
public class update {
        Statement stmt;
       
    


  
    public  void updateStudent (String stuid, String name, String address, String phone, String email, String course){

        Connection connection = null;
        PreparedStatement statement = null;
   
     
        try {
           // File image = new File("E:/ME.png");

           connection = DBConnection.getConnection();

            statement = connection.prepareStatement("UPDATE addstudent SET stuid=?, name=?,address= ?, phone=?, email=?,course= ? WHERE stuid=? ");

//  statement.setInt(1, 1);
            statement.setString(1,stuid);
            statement.setString(2,name);            
            statement.setString(3,address);
            statement.setString(4,phone);
            statement.setString(5,email);            
            statement.setString(6,course);
            statement.setString(7,stuid);
            
           
           statement.executeUpdate();
          
        
        
       
        } catch (SQLException e) 
            
        {
            System.out.println("SQLException: - " + e);
        } finally {

            try {
                connection.close();              
                statement.close();
            } catch (SQLException e) {
                System.out.println("SQLException Finally: - " + e);
            }
        } 
        
      

}

    
    //lecturer
    
    public void updateLecturer (String name, String address, String phone, String email, String faculty){

        Connection connection = null;
        PreparedStatement statement = null;
   
     
        try {
           // File image = new File("E:/ME.png");

           connection = DBConnection.getConnection();

            statement = connection.prepareStatement("UPDATE addlecturer SET  name=?,address= ?, phone=?, email=?, faculty=? WHERE name=? ");

//  statement.setInt(1, 1);
            statement.setString(1,name);            
            statement.setString(2,address);
            statement.setString(3,phone);
            statement.setString(4,email);
            statement.setString(5,faculty);
            statement.setString(6,name);
            
           
           statement.executeUpdate();
           
        
        
       
        } catch (SQLException e) 
            
        {
            System.out.println("SQLException: - " + e);
        } finally {

            try {
                connection.close();              
                statement.close();
            } catch (SQLException e) {
                System.out.println("SQLException Finally: - " + e);
            }
        } 
        
      

}
    //results
    
        public void updateResults (String stuid, String name, String semester, String module, double caMarks, double feMarks, double totalMarks, String grade){

        Connection connection = null;
        PreparedStatement statement = null;
   
     
        try {
           // File image = new File("E:/ME.png");

           connection = DBConnection.getConnection();

            statement = connection.prepareStatement("UPDATE exam SET  stuid=?,name= ?, semester=?, module=? , caMarks=? , feMarks=? , total=? , grade=? WHERE stuid=? ");

//  statement.setInt(1, 1);
            statement.setString(1,stuid);
            statement.setString(2,name);            
            statement.setString(3,semester);
            statement.setString(4,module);
            statement.setDouble(5,caMarks);            
            statement.setDouble(6,feMarks);
            statement.setDouble(7,totalMarks);
            statement.setString(8,grade);
            statement.setString(9,stuid);
           statement.executeUpdate();
           
        
        
       
        } catch (SQLException e) 
            
        {
            System.out.println("SQLException: - " + e);
        } finally {

            try {
                connection.close();              
                statement.close();
            } catch (SQLException e) {
                System.out.println("SQLException Finally: - " + e);
            }
        } 
        
      

}
    
          public void updatePayment (String stuid, String name, String semester, String amount){

        Connection connection = null;
        PreparedStatement statement = null;
   
     
        try {
           // File image = new File("E:/ME.png");

           connection = DBConnection.getConnection();

            statement = connection.prepareStatement("UPDATE payment SET  stuid=?, name= ?, semester=?, amount=? WHERE stuid=? ");

//  statement.setInt(1, 1);
            statement.setString(1,stuid);
            statement.setString(2,name);            
            statement.setString(3,semester);
            statement.setString(4,amount);
            statement.setString(5,stuid);
           statement.executeUpdate();
           
        
        
       
        } catch (SQLException e) 
            
        {
            System.out.println("SQLException: - " + e);
        } finally {

            try {
                connection.close();              
                statement.close();
            } catch (SQLException e) {
                System.out.println("SQLException Finally: - " + e);
            }
        } 
        
      

}      
        
}
