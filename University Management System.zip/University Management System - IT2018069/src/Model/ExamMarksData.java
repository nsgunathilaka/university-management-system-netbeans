/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;

/**
 *
 * @author Elitebook -PC
 */
public class ExamMarksData {
    
        Statement stmt;
    
        public void ExamMarks (String stuid, String name, String semester, String module, double caMarks, double feMarks, double totalMarks, String grade){
        try{
            
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate
        ("INSERT INTO exam VALUES ('"+stuid+"','"+name+"','"+semester+"','"+module+"','"+caMarks+"','"+feMarks+"','"+totalMarks+"','"+grade+"')");
    }
        catch (Exception e){
            e.printStackTrace();
        }
}
    
}
