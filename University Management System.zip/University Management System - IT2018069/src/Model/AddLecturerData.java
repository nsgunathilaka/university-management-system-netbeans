/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;
/**
 *
 * @author Hacker
 */
public class AddLecturerData {
    
    Statement stmt;
    
        public void Add_Lecturer (String name, String address, String phone, String email, String age, String gender, String faculty){
        try{
            
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate
        ("INSERT INTO addlecturer VALUES ('"+name+"','"+address+"','"+phone+"','"+email+"','"+age+"','"+gender+"','"+faculty+"')");
    }
        catch (Exception e){
            e.printStackTrace();
        }
}
}
