/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;

/**
 *
 * @author Hacker
 */
public class AddStudentData {
    
    Statement stmt;


    
    public void AddStudents (String stuid, String name, String address, String phone, String email, String course, String gender){
        try{
            
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate
        ("INSERT INTO addstudent VALUES ('"+stuid+"','"+name+"','"+address+"','"+phone+"','"+email+"','"+course+"','"+gender+"')");
    }
        catch (Exception e){
            e.printStackTrace();
        }
}

    public void AddStudents(String stuid, String name, int age, int phone, String email, String course, String gender) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
