
package Model;

import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Hacker
 */
public class DBSearch {

    private Statement stmt;
    private ResultSet rs;
    
    public ResultSet searchLogin(String usName){
        
        try{
            
            stmt = DBConnection.getStatementConnection();
            String name = usName;
            
            rs = stmt.executeQuery("SELECT * FROM login WHERE username='" + name + "'");
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return rs;
    }
   


    public ResultSet searchStudents(){
        try{
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT * FROM addstudent");
        }
        catch(Exception e){
            
            
        }
        return rs;
    }
    
        public ResultSet searchMarks(){
        try{
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT * FROM exam");
        }
        catch(Exception e){
            
            
        }
        return rs;
    }
    
        
        public ResultSet searchLecturer(){
        try{
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT * FROM addlecturer");
        }
        catch(Exception e){
            
            
        }
        return rs;
    }   
        
         public ResultSet searchPayment(){
        try{
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT * FROM payment");
        }
        catch(Exception e){
            
            
        }
        return rs;
    }  
         
                 public ResultSet searchResults(){
        try{
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT * FROM exam");
        }
        catch(Exception e){
            
            
        }
        return rs;
    }   
         
}