/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;

/**
 *
 * @author Elitebook -PC
 */
public class DBDelete {
    
        Statement stmt;
    public void deleteStudent(String name){
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("delete from addstudent where name='"+name+"'");
            
        }catch (Exception e){
        e.printStackTrace();
    }
}
    
    
    
    
    
    
    
    
        public void deleteLecturer(String name){
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("delete from addlecturer where name='"+name+"'");
            
        }catch (Exception e){
        e.printStackTrace();
    }
        
        
}
        
         public void deletePayment(String name){
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("delete from payment where name='"+name+"'");
            
        }catch (Exception e){
        e.printStackTrace();
    }
  
    

}
         
     public void deleteMarks(String stuid){
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("delete from exam where stuid='"+stuid+"'");
            
        }catch (Exception e){
        e.printStackTrace();
    }
        
        
}
}
